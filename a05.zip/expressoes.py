import cv2
from deepface import DeepFace

# carrega o classificador OpenCV
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)

# habilitar o uso da câmera
cap = cv2.VideoCapture(0)

print("Iniciando o modelo.")

total_homens = 0
total_mulheres = 0

while True:
    ret, frame = cap.read()

    if not ret:
        break

    # espelhar a imagem
    frame = cv2.flip(frame, 1)

    # ajusta cores da imagem para cinza
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # realiza detecção de rostos
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)



    for (x, y, w, h) in faces:

        # cria um retângulo ao redor do rosto
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # recorta o rosto
        roi_color = frame[y:y+h, x:x+w]

        try:
            analysis = DeepFace.analyze(
                roi_color,
                actions=['emotion', 'gender'],
                enforce_detection=False,
                detector_backend='opencv'
            )

            # compatibilidade com versões diferentes do DeepFace
            if isinstance(analysis, list):
                result = analysis[0]
            else:
                result = analysis

            dominant_emotion = result['dominant_emotion']

            genero = result['dominant_gender']

            if genero.lower() == "man":
                homens += 1
            else:
                mulheres += 1

            traducoes = {
                'angry': 'Raiva',
                'disgust': 'Nojo',
                'fear': 'Medo',
                'happy': 'Feliz',
                'sad': 'Triste',
                'surprise': 'Surpresa',
                'neutral': 'Neutro'
            }

            texto = traducoes.get(dominant_emotion, dominant_emotion)

            # escreve a emoção na tela
            cv2.putText(
                frame,
                texto,
                (x, y - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (0, 255, 0),
                2
            )

        except Exception as e:
            print("Erro:", e)
    cv2.putText(
        frame,
        f"Homens: {homens}  Mulheres: {mulheres}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (255, 0, 0),
        2
    )
    # mostra a imagem
    cv2.imshow('Detector de emoções', frame)

    # tecla Q encerra o programa
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# encerra câmera e janelas
cap.release()
cv2.destroyAllWindows()

