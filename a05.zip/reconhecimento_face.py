import cv2
from pathlib import Path
from playsound import playsound
import queue
import threading
import time

from face_registry import initialize_registry, list_people, recognize_face


initialize_registry()

# 2. Iniciar a Câmera (A Portaria)
cap = cv2.VideoCapture(0) # Use o IP do celular aqui se preferir

print("Sistema de Portaria Ativo.")

intervalo_verificacao = 1.0
confirmacoes_necessarias = 2
confirmacoes_consecutivas = 0
id_confirmacao = None
proxima_verificacao = 0.0
mensagem_status = "AGUARDANDO RECONHECIMENTO"
cor_status = (0, 165, 255)
resultados_verificacao = queue.Queue()
verificacao_em_andamento = False
ultimo_status_anunciado = None
trava_audio = threading.Lock()
pasta_projeto = Path(__file__).resolve().parent
audio_acesso_liberado = pasta_projeto / "acesso_liberado.mp3"
audio_acesso_negado = pasta_projeto / "acesso_negado.mp3"

for arquivo_audio in (audio_acesso_liberado, audio_acesso_negado):
    if not arquivo_audio.is_file():
        raise FileNotFoundError(f"Arquivo de audio nao encontrado: {arquivo_audio}")


def tocar_audio(arquivo_audio):
    if not trava_audio.acquire(blocking=False):
        return

    def reproduzir():
        try:
            playsound(str(arquivo_audio))
        except Exception as e:
            print(f"Erro ao reproduzir audio: {e}")
        finally:
            trava_audio.release()

    threading.Thread(target=reproduzir, daemon=True).start()


def verificar_rosto(frame):
    try:
        pessoa, erro = recognize_face(frame, list_people(active_only=True))
        resultados_verificacao.put((pessoa, erro))
    except Exception as e:
        resultados_verificacao.put((None, str(e)))

while True:
    ret, frame = cap.read()
    if not ret: break

    height, width, _ = frame.shape

    try:
        pessoa, erro = resultados_verificacao.get_nowait()
        verificacao_em_andamento = False
        proxima_verificacao = time.monotonic() + intervalo_verificacao
        if erro:
            if erro not in ("NO_FACE", "MULTIPLE_FACES", "NO_ACTIVE_PEOPLE", "DENIED"):
                print(f"Erro na leitura: {erro}")
            confirmacoes_consecutivas = 0
            mensagem_status = {
                "NO_FACE": "ROSTO NAO DETECTADO",
                "MULTIPLE_FACES": "APENAS UM ROSTO POR VEZ",
                "NO_ACTIVE_PEOPLE": "NENHUMA PESSOA AUTORIZADA",
                "DENIED": "ACESSO NEGADO",
            }.get(erro, "ERRO NA VERIFICACAO")
            cor_status = (0, 0, 220) if erro in ("MULTIPLE_FACES", "DENIED") else (0, 165, 255)
            if erro in ("MULTIPLE_FACES", "DENIED"):
                if ultimo_status_anunciado != "ACESSO NEGADO":
                    tocar_audio(audio_acesso_negado)
                    ultimo_status_anunciado = "ACESSO NEGADO"
            else:
                ultimo_status_anunciado = None
        elif pessoa:
            if id_confirmacao == pessoa["id"]:
                confirmacoes_consecutivas += 1
            else:
                id_confirmacao = pessoa["id"]
                confirmacoes_consecutivas = 1
            if confirmacoes_consecutivas >= confirmacoes_necessarias:
                mensagem_status = f"ACESSO LIBERADO: {pessoa['name']}"
                cor_status = (0, 180, 0)
                if ultimo_status_anunciado != pessoa["id"]:
                    tocar_audio(audio_acesso_liberado)
                    ultimo_status_anunciado = pessoa["id"]
            else:
                mensagem_status = "CONFIRMANDO IDENTIDADE 1/2"
                cor_status = (0, 165, 255)
        id_confirmacao = pessoa["id"] if pessoa else None
    except queue.Empty:
        pass

    agora = time.monotonic()
    if not verificacao_em_andamento and agora >= proxima_verificacao:
        mensagem_status = "VERIFICANDO IDENTIDADE..."
        cor_status = (0, 165, 255)
        verificacao_em_andamento = True
        threading.Thread(target=verificar_rosto, args=(frame.copy(),), daemon=True).start()
        proxima_verificacao = agora + intervalo_verificacao

    cv2.rectangle(frame, (100, 100), (width - 100, height - 100), (255, 0, 0), 2)
    cv2.rectangle(frame, (0, 0), (width, 60), cor_status, -1)
    cv2.putText(frame, mensagem_status, (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    cv2.imshow("Portaria", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()