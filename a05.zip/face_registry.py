from datetime import datetime, timezone
from functools import lru_cache
import os
from pathlib import Path
import shutil
import sqlite3
from uuid import uuid4

import cv2
import numpy as np

os.environ.setdefault("TF_NUM_INTRAOP_THREADS", "2")
os.environ.setdefault("TF_NUM_INTEROP_THREADS", "2")


PROJECT_DIR = Path(__file__).resolve().parent
DATABASE_PATH = PROJECT_DIR / "acessos.db"
PEOPLE_DIR = PROJECT_DIR / "pessoas_cadastradas"
MODEL_NAME = "VGG-Face"
DISTANCE_THRESHOLD = 0.40


def _connect():
    connection = sqlite3.connect(DATABASE_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_registry():
    PEOPLE_DIR.mkdir(parents=True, exist_ok=True)
    connection = _connect()
    try:
        with connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS people (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    image_path TEXT NOT NULL,
                    active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )
            migrated = connection.execute(
                "SELECT 1 FROM settings WHERE key = ?", ("legacy_face_imported",)
            ).fetchone()
            if not migrated:
                legacy_image = PROJECT_DIR / "face_id.jpg"
                if legacy_image.is_file():
                    person_id = str(uuid4())
                    person_image = PEOPLE_DIR / f"{person_id}.jpg"
                    shutil.copy2(legacy_image, person_image)
                    connection.execute(
                        """
                        INSERT INTO people (id, name, image_path, active, created_at)
                        VALUES (?, ?, ?, 1, ?)
                        """,
                        (
                            person_id,
                            "Morador cadastrado",
                            str(person_image),
                            datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        ),
                    )
                connection.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?)",
                    ("legacy_face_imported", "1"),
                )
    finally:
        connection.close()


def list_people(active_only=False):
    connection = _connect()
    try:
        if active_only:
            rows = connection.execute(
                "SELECT * FROM people WHERE active = 1 ORDER BY name COLLATE NOCASE"
            ).fetchall()
        else:
            rows = connection.execute(
                "SELECT * FROM people ORDER BY name COLLATE NOCASE"
            ).fetchall()
        return [dict(row) for row in rows]
    finally:
        connection.close()


def _validate_face(image):
    from deepface import DeepFace

    faces = DeepFace.extract_faces(
        img_path=image,
        detector_backend="opencv",
        enforce_detection=True,
    )
    if len(faces) != 1:
        raise ValueError("A foto precisa mostrar exatamente um rosto.")


@lru_cache(maxsize=128)
def _reference_embedding(image_path, modified_time_ns):
    from deepface import DeepFace

    representations = DeepFace.represent(
        img_path=image_path,
        model_name=MODEL_NAME,
        detector_backend="opencv",
        enforce_detection=True,
    )
    if len(representations) != 1:
        raise ValueError("A foto cadastrada deve conter exatamente um rosto.")
    return tuple(float(value) for value in representations[0]["embedding"])


def add_person(name, image_bytes):
    name = name.strip()
    if not name:
        raise ValueError("Informe o nome da pessoa.")

    image = cv2.imdecode(np.frombuffer(image_bytes, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("Nao foi possivel abrir a imagem. Use JPG ou PNG.")
    _validate_face(image)

    person_id = str(uuid4())
    image_path = PEOPLE_DIR / f"{person_id}.jpg"
    if not cv2.imwrite(str(image_path), image, [cv2.IMWRITE_JPEG_QUALITY, 95]):
        raise OSError("Nao foi possivel salvar a foto da pessoa.")

    connection = _connect()
    try:
        with connection:
            connection.execute(
                """
                INSERT INTO people (id, name, image_path, active, created_at)
                VALUES (?, ?, ?, 1, ?)
                """,
                (
                    person_id,
                    name,
                    str(image_path),
                    datetime.now(timezone.utc).isoformat(timespec="seconds"),
                ),
            )
    except Exception:
        image_path.unlink(missing_ok=True)
        raise
    finally:
        connection.close()
    return person_id


def set_person_active(person_id, active):
    connection = _connect()
    try:
        with connection:
            connection.execute(
                "UPDATE people SET active = ? WHERE id = ?",
                (int(active), person_id),
            )
    finally:
        connection.close()


def delete_person(person_id):
    connection = _connect()
    try:
        row = connection.execute(
            "SELECT image_path FROM people WHERE id = ?", (person_id,)
        ).fetchone()
        if row is None:
            return
        with connection:
            connection.execute("DELETE FROM people WHERE id = ?", (person_id,))
    finally:
        connection.close()

    image_path = Path(row["image_path"]).resolve()
    if image_path.parent == PEOPLE_DIR.resolve():
        image_path.unlink(missing_ok=True)


def recognize_face(image, people=None):
    from deepface import DeepFace
    from deepface.modules.verification import find_distance

    if people is None:
        people = list_people(active_only=True)
    if not people:
        return None, "NO_ACTIVE_PEOPLE"

    try:
        representations = DeepFace.represent(
            img_path=image,
            model_name=MODEL_NAME,
            detector_backend="opencv",
            enforce_detection=True,
        )
    except Exception:
        return None, "NO_FACE"
    if len(representations) != 1:
        return None, "MULTIPLE_FACES"
    query_embedding = tuple(
        float(value) for value in representations[0]["embedding"]
    )

    best_match = None
    best_distance = float("inf")
    for person in people:
        try:
            image_path = Path(person["image_path"])
            reference_embedding = _reference_embedding(
                str(image_path), image_path.stat().st_mtime_ns
            )
            distance = float(find_distance(query_embedding, reference_embedding, "cosine"))
        except Exception:
            continue

        if distance <= DISTANCE_THRESHOLD and distance < best_distance:
            best_match = person
            best_distance = distance

    return best_match, None if best_match else "DENIED"