from threading import Lock, Thread
from time import monotonic
from pathlib import Path

import cv2
from playsound import playsound
import av
from streamlit_webrtc import VideoProcessorBase

from face_registry import list_people, recognize_face


INFERENCE_INTERVAL_SECONDS = 1.2


class LiveAccessProcessor(VideoProcessorBase):
    def __init__(self):
        self._state_lock = Lock()
        self._inference_lock = Lock()
        self._audio_lock = Lock()
        self._last_inference = 0.0
        self._matched_person_id = None
        self._matches_in_a_row = 0
        self._status = "AGUARDANDO CAMERA"
        self._status_color = (0, 165, 255)
        self._announcement_id = 0
        self._announcement = None
        self._last_announcement = None

    def _set_status(self, status, color, announcement=None, reset_announcement=False):
        announcement_to_play = None
        with self._state_lock:
            self._status = status
            self._status_color = color
            if reset_announcement:
                self._last_announcement = None
            if announcement is not None and announcement != self._last_announcement:
                self._announcement_id += 1
                self._announcement = announcement
                self._last_announcement = announcement
                announcement_to_play = announcement

        if announcement_to_play:
            Thread(
                target=self._play_announcement,
                args=(announcement_to_play,),
                daemon=True,
            ).start()

    def _play_announcement(self, announcement):
        if not self._audio_lock.acquire(blocking=False):
            return
        try:
            audio_path = Path(__file__).resolve().parent / f"acesso_{announcement}.mp3"
            playsound(str(audio_path))
        except Exception as error:
            print(f"Erro ao reproduzir audio: {error}")
        finally:
            self._audio_lock.release()

    def snapshot(self):
        with self._state_lock:
            return self._status, self._announcement_id, self._announcement

    def _verify(self, image):
        try:
            person, error = recognize_face(image, list_people(active_only=True))
            if person:
                if person["id"] == self._matched_person_id:
                    self._matches_in_a_row += 1
                else:
                    self._matched_person_id = person["id"]
                    self._matches_in_a_row = 1

                if self._matches_in_a_row >= 2:
                    self._set_status(
                        f"ACESSO LIBERADO: {person['name']}",
                        (0, 150, 0),
                        announcement="liberado",
                    )
                else:
                    self._set_status("CONFIRMANDO IDENTIDADE...", (0, 165, 255))
                return

            self._matched_person_id = None
            self._matches_in_a_row = 0
            statuses = {
                "NO_FACE": ("PROCURANDO ROSTO", (0, 165, 255)),
                "MULTIPLE_FACES": ("APENAS UM ROSTO POR VEZ", (0, 0, 220)),
                "NO_ACTIVE_PEOPLE": ("NENHUM ACESSO ATIVO", (0, 165, 255)),
                "DENIED": ("ACESSO NEGADO", (0, 0, 220)),
            }
            status, color = statuses.get(error, ("ERRO NA VERIFICACAO", (0, 0, 220)))
            announcement = "negado" if error == "DENIED" else None
            self._set_status(
                status,
                color,
                announcement=announcement,
                reset_announcement=error != "DENIED",
            )
        except Exception:
            self._matched_person_id = None
            self._matches_in_a_row = 0
            self._set_status("ERRO NA VERIFICACAO", (0, 0, 220), reset_announcement=True)
        finally:
            self._inference_lock.release()

    def process_frame(self, image):
        if image.shape[1] > 640:
            scale = 640 / image.shape[1]
            image = cv2.resize(
                image,
                (640, int(image.shape[0] * scale)),
                interpolation=cv2.INTER_AREA,
            )

        now = monotonic()
        if (
            now - self._last_inference >= INFERENCE_INTERVAL_SECONDS
            and self._inference_lock.acquire(blocking=False)
        ):
            self._last_inference = now
            self._set_status("ANALISANDO ROSTO...", (0, 165, 255))
            Thread(target=self._verify, args=(image.copy(),), daemon=True).start()

        with self._state_lock:
            status = self._status
            color = self._status_color

        cv2.rectangle(image, (0, 0), (image.shape[1], 58), color, -1)
        cv2.putText(
            image,
            status,
            (18, 39),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        return image

    def recv(self, frame):
        image = frame.to_ndarray(format="bgr24")
        return av.VideoFrame.from_ndarray(self.process_frame(image), format="bgr24")