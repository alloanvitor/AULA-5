import streamlit as st
from streamlit_webrtc import WebRtcMode, webrtc_streamer

from face_registry import (
    add_person,
    delete_person,
    initialize_registry,
    list_people,
    set_person_active,
)
from live_access import LiveAccessProcessor


st.set_page_config(page_title="Controle de acesso", page_icon=":material/face:", layout="wide")
initialize_registry()

st.title("Controle de acesso")
pagina = st.segmented_control(
    "Área",
    ["Verificar acesso", "Cadastros"],
    default="Verificar acesso",
    key="pagina",
)

if pagina == "Verificar acesso":
    st.subheader("Verificar acesso")
    pessoas_ativas = list_people(active_only=True)
    if not pessoas_ativas:
        st.info("Cadastre uma pessoa com acesso ativo para iniciar o reconhecimento.")

    context = webrtc_streamer(
        key="verificacao-ao-vivo",
        mode=WebRtcMode.SENDRECV,
        rtc_configuration={
            "iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]
        },
        media_stream_constraints={
            "video": {
                "width": {"ideal": 640, "max": 640},
                "height": {"ideal": 480, "max": 480},
                "frameRate": {"ideal": 12, "max": 12},
            },
            "audio": False,
        },
        video_processor_factory=LiveAccessProcessor,
        async_processing=True,
        video_receiver_size=1,
        desired_playing_state=True,
    )

    @st.fragment(run_every="2s")
    def status_ao_vivo():
        processor = context.video_processor
        if processor is not None:
            snapshot = getattr(processor, "snapshot", None)
            if snapshot is not None:
                st.caption(snapshot()[0])

    status_ao_vivo()

elif pagina == "Cadastros":
    secao = st.segmented_control(
        "Cadastros",
        ["Pessoas", "Cadastrar pessoa"],
        default="Pessoas",
        key="secao-cadastros",
    )

    if secao == "Pessoas":
        pessoas = list_people()
        ativas = sum(person["active"] for person in pessoas)
        metricas = st.columns(2)
        metricas[0].metric("Pessoas cadastradas", len(pessoas))
        metricas[1].metric("Acessos ativos", ativas)
        st.subheader("Pessoas")

        if not pessoas:
            st.info("Ainda nao ha pessoas cadastradas.")

        for pessoa in pessoas:
            with st.container(border=True):
                foto, detalhes, acoes = st.columns([1, 4, 2])
                image_path = pessoa["image_path"]
                if image_path:
                    foto.image(image_path, width=90)
                detalhes.markdown(f"**{pessoa['name']}**")
                detalhes.caption(
                    f"{'Acesso ativo' if pessoa['active'] else 'Acesso revogado'} · "
                    f"Cadastro em {pessoa['created_at'][:10]}"
                )
                if pessoa["active"]:
                    if acoes.button("Revogar acesso", key=f"revoke-{pessoa['id']}", icon=":material/block:"):
                        set_person_active(pessoa["id"], False)
                        st.rerun()
                else:
                    if acoes.button("Reativar acesso", key=f"activate-{pessoa['id']}", icon=":material/check_circle:"):
                        set_person_active(pessoa["id"], True)
                        st.rerun()

                if st.session_state.get("excluir_pessoa") == pessoa["id"]:
                    st.warning(f"Excluir o cadastro de {pessoa['name']} e sua foto?")
                    confirmar, cancelar = st.columns(2)
                    if confirmar.button("Confirmar exclusao", key=f"confirm-delete-{pessoa['id']}", type="primary"):
                        delete_person(pessoa["id"])
                        del st.session_state["excluir_pessoa"]
                        st.rerun()
                    if cancelar.button("Cancelar", key=f"cancel-delete-{pessoa['id']}"):
                        del st.session_state["excluir_pessoa"]
                        st.rerun()
                elif acoes.button("Excluir", key=f"delete-{pessoa['id']}", icon=":material/delete:"):
                    st.session_state["excluir_pessoa"] = pessoa["id"]
                    st.rerun()

    elif secao == "Cadastrar pessoa":
        st.subheader("Novo cadastro")
        origem = st.segmented_control(
            "Origem da foto",
            ["Tirar foto", "Importar arquivo"],
            default="Tirar foto",
            key="origem-cadastro",
        )
        foto = None
        if origem == "Tirar foto":
            foto = st.camera_input("Tirar foto do rosto", key="camera-cadastro", resolution="720p")
        else:
            foto = st.file_uploader(
                "Selecionar foto",
                type=["jpg", "jpeg", "png", "webp"],
                key="arquivo-cadastro",
            )

        nome = st.text_input("Nome da pessoa", max_chars=80)
        if foto:
            st.image(foto, caption="Foto selecionada", width=320)

        if st.button("Cadastrar e liberar acesso", type="primary", icon=":material/person_add:"):
            if foto is None:
                st.error("Tire uma foto ou selecione um arquivo.")
            else:
                try:
                    with st.spinner("Validando o rosto e salvando o cadastro..."):
                        add_person(nome, foto.getvalue())
                    st.success(f"Acesso liberado para {nome.strip()}.")
                except ValueError as error:
                    st.error(str(error))
                except Exception as error:
                    st.error(f"Nao foi possivel concluir o cadastro: {error}")